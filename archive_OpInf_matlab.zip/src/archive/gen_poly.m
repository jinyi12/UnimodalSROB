function resultArray = gen_poly(X, p)
    % Compute polynomial terms for a 2D array X transposed, where each row
    % is a variable and each column a sample, based on provided multiIndices.
    % The output is structured so that each row corresponds to a polynomial
    % term and each column to a sample.

    [N, M] = size(X); % N is the number of variables, M is the number of samples

    multiIndices = generateMultiIndicesEfficient(N, p);

    % disp("Generated multi indices are")
    % disp(multiIndices)

    % Compute the maximum degree of the polynomial
    maxDegree = 2 * p;
    % disp(['Maximum Degree: ', num2str(maxDegree)]);
    
    % Pre-compute powers of each variable (row in X) up to the maximum degree
    powers = ones(N, maxDegree + 1, M);
    for n = 1:N
        for degree = 1:maxDegree
            powers(n, degree + 1, :) = X(n, :) .^ degree;
        end
    end
    
    % Initialize the result array to store the computed polynomial term for each multi-index
    resultArray = ones(size(multiIndices, 1), M);
    
    for i = 1:size(multiIndices, 1)
        indices = multiIndices(i, :);
        term = ones(1, M);
        for n = 1:N
            power = indices(n) + 1; % Adjust for MATLAB indexing
            if power > 1 % Skip if power is 0 (1 in MATLAB indexing)
                term = term .* squeeze(powers(n, power, :))';
            end
        end
        resultArray(i, :) = term;
    end
end



function validDegrees = generateMultiIndicesEfficient(numVars, p)
    maxDegree = 2*p;
    % Generate all monomial degrees combinations
    degrees = monomialDegrees(numVars, maxDegree);

    % disp("Generated monomial degrees")
    % disp(size(degrees, 1))
    
    % Vectorized filtering criteria:
    % 1. Sum of indices is between 3 and 2*p inclusive
    sumCondition = sum(degrees, 2) >= 3 & sum(degrees, 2) <= 2*p;
    
    % 2. At most two non-zero entries
    nonZeroCondition = sum(degrees > 0, 2) <= 2;
    
    % 3. No entry is greater than p if there are more than one non-zero entries
    moreThanOneNonZero = sum(degrees > 0, 2) > 1;
    maxCondition = max(degrees, [], 2) <= p | ~moreThanOneNonZero;

    % disp("Amount of valid for max condition")
    % disp(sum(maxCondition))
    
    % disp("Amount of valid for non-zero condition")
    % disp(sum(nonZeroCondition))

    % disp("Amount of valid for sum condition")
    % disp(sum(sumCondition))

    % Combine conditions using element-wise logical AND
    validIdx = sumCondition & nonZeroCondition & maxCondition;
    
    % Select valid degrees based on the combined criteria
    validDegrees = degrees(validIdx, :);

    % Sort the valid degrees based on the sum of degrees and lexicographically
    [~, sortIdx] = sortrows([sum(validDegrees, 2), validDegrees]);
    validDegrees = validDegrees(sortIdx, :);

end

function degrees = monomialDegrees(numVars, maxDegree)
    if numVars == 1
        degrees = (0:maxDegree).';
        return;
    end
    degrees = cell(maxDegree + 1, 1);
    k = numVars;
    for n = 0:maxDegree
        dividers = flipud(nchoosek(1:(n + k - 1), k - 1));
        degrees{n + 1} = [dividers(:,1), diff(dividers, 1, 2), (n + k) - dividers(:,end)] - 1;
    end
    degrees = cell2mat(degrees);
end




function total_unique_monomials = calculate_combinatorial(r, p)
    % Count for single-variable monomials
    single_variable_count = r * (2*p - 2);

    % Initialize count for two-variable monomials
    two_variable_count = 0;
    
    % Calculate two-variable monomial counts
    for d = 3:(2*p + 1)
        for i = 1:min(p, d-1) + 1
            if d - i <= p
                % Choose any two variables out of r for the monomial
                two_variable_count = two_variable_count + nchoosek(r, 2);
            end
        end
    end
    
    % Total unique monomials is the sum of single and two-variable counts
    total_unique_monomials = single_variable_count + two_variable_count;
end
